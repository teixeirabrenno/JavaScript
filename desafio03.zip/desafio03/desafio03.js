function Contar(){
    let a1 = document.getElementById('txtInicio').value
    let an = document.getElementById('txtFim').value
    let r = document.getElementById('txtRazao').value
    let resultado = document.getElementById('resultado')

    for(a1; a1 <= an; a1 = a1 + r){
        resultado.innerText = a1
        console.log(a1)
    }
    


    // if (a1.value.length == 0 || an.value.length == 0 || r.value.length == 0 || r == 0) {
    //     alert('Os dados estão preenchidos de forma inadequada.')
    // } else if (a1 > an && r < 0) {
    //     for (a1; a1 != an; a1 = a1 + r){
    //         resultado.innerText = a1
    //     }
    // }



    }


    // for(a1; a1 <= an; a = a + r)